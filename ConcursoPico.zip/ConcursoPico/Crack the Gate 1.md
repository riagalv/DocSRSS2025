#Reto 
## Descripcion del reto
We’re in the middle of an investigation. One of our persons of interest, ctf player, is believed to be hiding sensitive data inside a restricted web portal. We’ve uncovered the email address he uses to log in: `ctf-player@picoctf.org`. Unfortunately, we don’t know the password, and the usual guessing techniques haven’t worked. But something feels off... it’s almost like the developer left a secret way in. Can you figure it out?The website is running [here](http://amiable-citadel.picoctf.net:55066/). Can you try to log in?
## Solucion
picoCTF{brut4_f0rc4_cbb8faa7}
abrimos la web terminal de la pagina y ponemos este script
![[Pasted image 20251012142559.png]]
y nos empieza a soltar la bandera
![[Pasted image 20251012142621.png]]
## Notas

## Referencias
