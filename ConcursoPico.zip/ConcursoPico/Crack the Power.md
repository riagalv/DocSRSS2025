#Reto 
## Descripcion del reto
We received an encrypted message. The modulus is built from primes large enough that factoring them isn’t an option, at least not today. See if you can make sense of the numbers and reveal the flag.Download the [message](https://challenge-files.picoctf.net/c_amiable_citadel/17844e1db2c883adfc82f6601dfed7514cfbfce479cf0f0e63b32abb4aab8fc5/message.txt).
## Solucion
picoCTF{t1ny_e_af0d7666}
hacemos un codigo usando el descargable del reto, para poder resolver el reto
![[Pasted image 20251014132647.png]]
![[Pasted image 20251014132727.png]]
corremos el codigo
![[Pasted image 20251014132533.png]]
## Notas

## Referencias
